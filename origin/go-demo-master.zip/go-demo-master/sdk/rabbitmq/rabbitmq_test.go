package mq

import "testing"

func TestRabbitMq(t *testing.T) {
	t.Log("RabbitMQ Success!")
}
