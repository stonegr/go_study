package boot

import (
	_ "go-demo/sdk/gf/packed"
)

func init() {

}
