# Go爬虫项目

### gift
> QQ群自动抽礼物爬虫，可部署到服务器中，每天定时抽取群礼物，
Cookie需要使用抓包工具自己获取，这里推荐使用`NetKeeper`,操作非常容易
执行build.bat脚本可打包成Linux可执行程序


### qq
> QQ快速登录有漏洞，通过分析QQ快速登录协议，
实现获取QQ的`p_seky`