package facade

import "testing"

func TestFacade(t *testing.T) {
	startBtn := &StartBtn{}
	startBtn.start()
}
