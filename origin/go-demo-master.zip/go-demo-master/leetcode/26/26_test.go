package main

import "testing"

func TestNumWays(t *testing.T) {
	// 7  -> 21
	t.Log(numWays(7))
}
