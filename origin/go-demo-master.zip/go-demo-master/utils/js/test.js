function test(name) {
    return "Hello: " + name
}

// 由go进行完成
sayHello("pibigstar");