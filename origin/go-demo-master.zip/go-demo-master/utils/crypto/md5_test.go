package utils

import (
	"testing"
)

func TestMd5(t *testing.T) {
	t.Log(Md5("pibigstar"))
}
