package code

import "testing"

func TestGenCodeImage(t *testing.T) {
	GenCodeImage(6)
}
