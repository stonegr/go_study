// 自定义函数，并通过go来实现C函数
void SayHello(char* s);