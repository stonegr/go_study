#include <stdio.h>

int SayHello() {
    puts("Hello World");
    return 0;
}