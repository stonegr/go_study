# GO的Socket编程

## 实现一个简单的聊天室
1. 运行server.go
2. 运行client.go
