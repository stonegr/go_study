package outer

import (
	_ "go-demo/base/instruct/linkname/impl"
)

func Linkname()
