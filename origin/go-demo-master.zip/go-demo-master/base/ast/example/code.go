package example

const (
	Test1 = 1 // 测试1
	Test2 = 2 // 测试2
	Test3 = 3 // 测试3
	Test4 = 4 // 测试4
)
